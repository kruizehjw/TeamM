var startDate = new Date(); // beware: month 0 = january, 11 = december
var ddDate = new Date(); // beware: month 0 = january, 11 = december
var endDate = new Date();
var title = "My nice event";
var where = "Home";
var notes = "Some notes about this event.";
var calSuccess = function(message) { 
                                  alert("Success: " + JSON.stringify(message));
                                   };
var calSuccesss = function(message) {
       alert("find Success: " + JSON.stringify(message));
       $.each(message,function(i,tweet) {
            alert(JSON.stringify(tweet));
            //Indien gevonden dan verwijderen met oude gevonden startdatum en dezelfde einddatum (helaas nog noodzakelijk)
            var thisDateT = tweet.startDate.substr(0, 10) + "T" + tweet.startDate.substr(11, 8);
            var thisDate  = new Date(thisDateT);
            //alert(thisDate);
            window.plugins.calendar.deleteEvent(tweet.title,tweet.location,tweet.message,thisDate,endDate);
            //window.plugins.calendar.createEvent(title,where,notes,startDate,endDate);

              });
       //Voeg evenement toe met nieuwe startdatum en einddatum
       alert('create');
       window.plugins.calendar.createEvent(title,where,notes,startDate,endDate);
       };

var calError = function(message) { alert("Error: " + message); };

var calOptions = window.plugins.calendar.getCalendarOptions(); // grab the defaults
calOptions.firstReminderMinutes = 120; // default is 60, pass in null for no reminder (alarm)


function calendarDemoAdd() {
           //alert('Test');                     
    var url3='http://ts.teamm.nl:8195/ordsdev/apex_rest.getReport?app=110&page=10&reportid=dienstenkortsync&parmvalues='+localStorage.getItem('teamprofiel')+'&output=json';
    $.getJSON(url3,function(json) {
        //Loop door de wedstrijden.
         //alert(JSON.stringify(json));
	$.each(json.row,function(i,tweet) {
                              // alert('delete');
              startDate = new Date(tweet.JAAR,tweet.MAAND,tweet.DAG,tweet.UUR,tweet.MIN,0,0,0);
              ddDate = new Date();
              endDate = new Date(tweet.JAAR,tweet.MAAND,tweet.DAG,tweet.UUR2,tweet.MIN2,0,0,0);
	      where = 'Op lokatie';
              title = tweet.ID;
	      notes = 'Opmerkingen : '+tweet.ID;
              window.plugins.calendar.deleteEvent(title,where,notes,ddDate,endDate);
             
        });
         //alert('Rijen verwijderd');
       $.each(json.row,function(i,tweet) {
               // alert('Insert');

              startDate = new Date(tweet.JAAR,tweet.MAAND,tweet.DAG,tweet.UUR,tweet.MIN,0,0,0);
              ddDate = new Date();
              endDate = new Date(tweet.JAAR,tweet.MAAND,tweet.DAG,tweet.UUR2,tweet.MIN2,0,0,0);
	      where = 'Op lokatie';
              title = tweet.ID;
	      notes = 'Opmerkingen : '+tweet.ID;
              //alert(notes);
              window.plugins.calendar.createEvent(title,where,notes,startDate,endDate);
              //alert('einde');
              
        });
       alert('Rooster is gesynchroniseerd');
        
    });  
}