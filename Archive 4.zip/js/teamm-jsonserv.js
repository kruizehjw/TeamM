/*
 Naam  : teamm-jsonserv.js
 Datum : 15-05-2016
 Auteur: Henk Kruize
 
 lees_rooster         : Laden data vanuit local storage en html opbouwen
 lees_rooster_lok     : Laden data vanuit local storage en data verwijderen uit native calendar
 lees_rooster_cal     : Laden data vanuit local storage/url  en toevoegen aan native calendar
 lees_diensten        : 
 lees_berichten
 lees_verzuim
 
 calendarTeamM        : lees_rooster_lok, lees data via url, lees_rooster_cal 
 lees_menu_init       : Menu met enkel profiel/info bij niet geautoriseerde gebruikers
 lees_menu_tot        : Menu voor geautoriseerde gebruikers
 
 lees_bezoeken        : Extraheer bezoeken uit localstorage(diensten) voor dienstid=
 lees_taken           : Extraheer taken uit localstorage(diensten) voor dienstid= en bezoekid= 
 
 opslag_bezoektijden  : Opslaan in localstorage de bezoektijden
 sync_opslagtijden    : Syncrhoniseer met database

*/
 
            
      	    function lees_rooster(p_json) {
                  var content = '';
                  content += '<ul>';
                  if (JSON.stringify(p_json)!='null') { //storage of remote heeft waarde
		     if (JSON.stringify(p_json).search('No data found') == -1 ) {
		        $.each(p_json.items,function(i,tweet) {
                              content += '<li><a href="javascript:test('+tweet.dienstid+');" class="teamm"><i>';
                              //content += '<li><i>';
                              if (tweet.ddmodified == 'Y') {
                                    content += '<img src="images/teamm-new24.png" alt="">'
                              }
                              else {
                                    if (tweet.bericht == 'Y') {
                                       content += '<img src="images/teamm-ber24.png" alt="">'
                                    }
                                    else {
                                       content += '<img src="images/teamm-blanco24.png" alt="">'
                                    }
                              }
                              content +='</i><span class="day_name">'+tweet.dag+' '+tweet.datum+'<br>'+tweet.klant+
                              '<br>Duur <div style="display:inline;padding: 0px 0px 0px 30px;">'+tweet.duur+'</div>'+
                              //'<br>Duur <div style="display:inline;padding: 0px 0px 0px 30px;"><input id="duurveld" class="dienstneg" name="duur" value="'+tweet.DUUR+'" type="time"/></div>'+
                              '</span><label>'+tweet.tijd+
                              '</label><div class="clear"></div></a></li>';
                             // '</label><div class="clear"></div></li>';

								        
                          });
		     }
                  }
		  content += '</ul>'; 
                //  $("#teamm-rooster").append(content);
                  $("#teamm-rooster").html(content);
	    }

     	    function lees_rooster_lok(p_json) {
                  //
                  // Verwijderen items uit calendar
                  //
                  var startDate = new Date(2015,2,15,18,30,0,0,0); // beware: month 0 = january, 11 = december
                  var endDate = new Date(2015,2,15,19,30,0,0,0);
                  var success = function(message) { alert("Success: " + JSON.stringify(message)); };
                  var error = function(message) { alert("Error: " + message); };

                  if (JSON.stringify(p_json)!='null') { //storage of remote heeft waarde
		     if (JSON.stringify(p_json).search('No data found') == -1 ) {
		        $.each(p_json.row,function(i,tweet) {
                              startDate = new Date(tweet.JAAR,tweet.MAAND,tweet.DAG,tweet.UUR,tweet.MIN,0,0,0);
                              ddDate = new Date();
                              endDate = new Date(tweet.JAAR,tweet.MAAND,tweet.DAG,tweet.UUR2,tweet.MIN2,0,0,0);
                              ddDate2 = new Date();
                              where = 'Op lokatie';
                              title = tweet.ID;
                              notes = 'Opmerkingen : '+tweet.ID;
                              //window.plugins.calendar.deleteEvent(title,where,notes,ddDate,endDate);
                              //window.plugins.calendar.deleteEvent(title);
                              where ='';
                              notes ='';
                              // Event wordt verwijderd als title en eindtijd gelijk zijn.
                              //window.plugins.calendar.findEvent(title,where,notes,ddDate,ddDate2,success,error);
                              window.plugins.calendar.deleteEvent(title,where,notes,ddDate,endDate);

                          });
		     }
                  }
	    }

     	    function lees_rooster_cal(p_json) {
                  //
                  // Toevoegen items in calendar
                  //
                  if (JSON.stringify(p_json)!='null') { //storage of remote heeft waarde
		     if (JSON.stringify(p_json).search('No data found') == -1 ) {
		        $.each(p_json.row,function(i,tweet) {
                              startDate = new Date(tweet.JAAR,tweet.MAAND,tweet.DAG,tweet.UUR,tweet.MIN,0,0,0);
                              ddDate = new Date();
                              endDate = new Date(tweet.JAAR,tweet.MAAND,tweet.DAG,tweet.UUR2,tweet.MIN2,0,0,0);
                              where = 'Op lokatie';
                              title = tweet.ID;
                              notes = 'Opmerkingen : '+tweet.ID;
                              //alert(notes);
                              window.plugins.calendar.createEvent(title,where,notes,startDate,endDate);
                              //alert('einde');
                          });
		     }
                  }
	    }
            
      	    function lees_diensten(p_json) {
                  var content = '';
                  content += '<ul>';
                  if (JSON.stringify(p_json)!='null') { //storage of remote heeft waarde
		     if (JSON.stringify(p_json).search('No data found') == -1 ) {
		        $.each(p_json.row,function(i,tweet) {
                              content += '<li><a href="#" class="teamm"><i><div id="'+tweet.ID+'img">';
                              if (tweet.STATUS == 'positief gereageerd') {
                                    content += '<img src="images/teamm-cal-checked24.png" alt="">'
                              }
                              else if (tweet.STATUS == 'aangeboden') {
                                     content += '<img src="images/teamm-new24.png" alt="">'
                              }
                              else if (tweet.STATUS == 'ingepland') {
                                     content += '<img src="images/teamm-cal-checked24.png" alt="">'
                              }
                              else {
                                    content += '<img src="images/teamm-blanco24.png" alt="">'
                              }
                              if (sessionStorage.teamonline=='N') {
                              content +='</div></i><span class="day_name" style="width:60%">'+tweet.DAG+' '+tweet.DATUM+'<br>'+tweet.KLANT+
                                       '<div style="display: none;"><br></div></span><label>'+tweet.TIJD+'</label><div class="clear"></div></a></li>';

                              }
                              else {
                              content +='</div></i><span class="day_name" style="width:60%">'+tweet.DAG+' '+tweet.DATUM+'<br>'+tweet.KLANT+
                                       '<div style="text-align:center; display: none;"><br><img class="dienstneg" id="'+tweet.ID+'" src="images/teamm-cal-unchecked64.png" alt="">'+
			               '<img class="dienstpos" id="'+tweet.ID+'" src="images/teamm-cal-checked64.png" alt=""></div></span><label>'+tweet.TIJD+'</label><div class="clear"></div></a></li>';
                                   
                              }
 
								        
                          });
		     }
                  }
		  content += '</ul>'; 
                  $("#teamm-diensten").html(content);
	    }


	    function lees_berichten(p_json) {
                  var content = '';
                  content += '<ul>';
                  if (JSON.stringify(p_json)!='null') { //storage of remote heeft waarde
		     if (JSON.stringify(p_json).search('No data found') == -1 ) {
		        $.each(p_json.row,function(i,tweet) {
                              
                              if (tweet.TELLER == '1') {
                                 content += '<li><a href="#" class="teamm">';
                                 content += '<span class="day_name">'+tweet.AAN+'<br>betreft: '+tweet.ONDERWERP+'<br>'+tweet.TEKST1+tweet.DATUM+
                                    		               '<div style="display: none;">'+tweet.TEKST2+'</div></span><label style="float:right;padding:10px">';
                                 content +=tweet.BERICHT_SOORT_CODE+'</label><div class="clear"></div>';
                                 if (tweet.LAATSTE == 'Y') {
                                    content +='</a></li>';
                                 }
                              }
                              else{
                                if (tweet.LAATSTE == 'Y') {
                                   content += '<span class="day_name">'+tweet.AAN+'<br>betreft: '+tweet.ONDERWERP+'<br>'+tweet.TEKST1+tweet.DATUM+
                                    		               '<div style="display: none;">'+tweet.TEKST2+'</div></span><label style="float:right;padding:10px">';
                                   content +='</label><div class="clear"></div></a></li>';
                                }
                                else {
                                   content += '<span class="day_name">'+tweet.AAN+'<br>betreft: '+tweet.ONDERWERP+'<br>'+tweet.TEKST1+tweet.DATUM+
                                    		               '<div style="display: none;">'+tweet.TEKST2+'</div></span><label style="float:right;padding:10px">';
                                   content +='</label><div class="clear"></div>';
                                }
                              }
                              
//                              content += '<li><a href="#" class="teamm">';
//                              content += '<span class="day_name">'+tweet.AAN+'<br>betreft: '+tweet.ONDERWERP+'<br>'+tweet.TEKST1+tweet.DATUM+
//		               '<div style="display: none;">'+tweet.TEKST2+'</div></span><label style="float:right;padding:10px">';
//                               if (tweet.TELLER =='1') {
//                                     content +=tweet.BERICHT_SOORT_CODE+'</label><div class="clear"></div></a></li>';
//                               }
//                               else {
//                                  content +='</label><div class="clear"></div></a></li>';  
//                               }
                               
                               
                          });
		     }
                  }
		  content += '</ul>'; 
                  $("#teamm-berichten").html(content);
	    }

            
      	    function lees_verzuim(p_json) {
                  var content = '';
                  content += '<ul>';
                  if (JSON.stringify(p_json)!='null') { //storage of remote heeft waarde
		     if (JSON.stringify(p_json).search('ORA-') == -1 ) {
		        $.each(p_json.row,function(i,tweet) {
                              content += '<li><a href="#" class="teamm"><i><div id="'+tweet.ID+'img">';
                              content +='</div></i><span class="day_name">'+tweet.DATUM+
			               '</span><label></label><div class="clear"></div></a></li>';

								        
                          });
		     }

                  }
                  content += '<li style="border-bottom:0px"><a href="#" class="teamm"><span class="day_name"><div id="verzuimpje" style="display: none;"><br>Verzuim melden <input id="verzuimveld" class="dienstneg" name="verzuim" min="2016-05-18" type="date"/>'+
                             '<br><br><div id="verzuimdiv"><img id="verzuimbutton" src="images/teamm-checkedwit64.png" style="display:block;margin:0 auto;" alt=""></div></div></span><label></label><div class="clear"></div></a></li>';
		  content += '</ul>'; 
                  $("#teamm-verzuim").html(content);
	    }


            function calendarTeamM() {
                  //
                  // Lees huidig rooster uit storage sync (gelijk aan agenda) en verwijder uit agenda
                  //
                      lees_rooster_lok(JSON.parse(localStorage.getItem('teammroostersync'))); //Oud rooster
                      
                  //
                  // Lees actueel rooster uit database middels url
                  //       
                  var url3='http://ts.teamm.nl:8080/ordsprd/apex_rest.getReport?app='+localStorage.getItem('teammapp')+'&page=rooster&reportid=roostersync&parmvalues='+localStorage.getItem('teamprofiel')+'&output=json';
                  $.getJSON(url3,function(json) {
                        //
                        // Maak nieuwe calender-items aan en sla actuele items ook op in lokale storage
                        //     Kopieer naar lokale storage, voeg toe aan kalender
                        localStorage.setItem('teammroostersync', JSON.stringify(json));
                        lees_rooster_cal(json);
                        alert('Rooster is gesynchroniseerd');
                  });
            }
	    	                     
	    function lees_menu(p_json) {
                  var content = '';
		   var tel = 0;
                   content += '';                      
              if (JSON.stringify(p_json)!='null') {
	      if (JSON.stringify(p_json).search('No data found') == -1) {
		      $.each(p_json.row,function(i,tweet){
		        tel++;
		        //content += tweet.MENUITEM;
                        content += tweet.MENUITEM.replace("P200_TOKEN:","P200_TOKEN:"+localStorage.getItem('teamprofiel'));
                      });
		 //  }
	      }
              }
		   content += '';
                   $("#teammenu").append(content);
	    }
            
	    function lees_menu_tot() {
            //
            // menuopties als gebruiker is geautoriseerd
            //
                  var content = '';
                  var l_medewerker = localStorage.getItem('teamprofiel').toLowerCase();
                  content += '<li><a href="rooster.html"><span><i><img src="images/teamm-cal.png"></i> rooster</span></li>'+
                  '<li><a href="diensten.html"><span><i><img src="images/teamm-dienst.png"></i> diensten</span></li>'+
                  '<li><a href="berichten.html"><span><i><img src="images/teamm-ber.png"></i> berichten</span></li>'+
                  '<li><a href="verzuim.html"><span><i><img src="images/teamm-verzuim.png"></i> verzuim</span></li>';
                  if (l_medewerker) {
                        content +='<li><a href="uitloggen.html"><span><i><img src="images/teamm-profiel.png"></i> '+l_medewerker+'</span></li>';

                  }
                  else {
                        content +='<li><a href="profiel.html"><span><i><img src="images/teamm-profiel.png"></i> inloggen</span></li>';
                  }
                  content +='<li><a href="versie.html"><span><i><img src="images/teamm-versie.png"></i> info</span></li>';                        
                  $("#teammenu").html(content);
	    }            
            
	    function lees_menu_init() {
            //
            // menuopties als gebruiker niet is geautoriseerd
            //                  
                  var content = '';
            	  content +=  '<li><a href="profiel.html"><span><i><img src="images/teamm-profiel.png"></i> inloggen    </span></a></li>'+
                  '<li><a href="versie.html"><span><i><img src="images/teamm-versie.png"></i> info</span></a></li>';               
                   $("#teammenu").html(content);
	    }
            
            function lees_bezoeken(p_dienst) {
            // lees hoogste in boom
                  var content = '';
                  var l_duur  = '';
                  content += '<ul>';
                  $.each(p_dienst.items,function(i,dienstdata){
                  //alert(dienstdata.KLANT);
                        if (dienstdata.dienstid == sessionStorage.dienstid) {
                              l_duur = dienstdata.duur;
                              content += '<li><a  class="teamm">';
                              content +='<span class="day_name">'+dienstdata.dag+' '+dienstdata.datum+'<br>'+dienstdata.klant+'<br></span><label></label><div class="clear"></div></a></li>';
                              content += '<ul style="margin: 0px 0px 0px 30px;">';
                              if (JSON.stringify(dienstdata)!='null') {
                                    if (JSON.stringify(dienstdata).search('taken') > -1) {    //HK 20-06
                                          sessionStorage.bezoeken = JSON.stringify(dienstdata);
                                           $.each(dienstdata.bezoeken,function(j,bezoeken){
                                                sessionStorage.bezoekid = bezoeken.bezoek_id;
                                                content += '<li><a href="javascript:taken('+bezoeken.bezoek_id+')" class="teamm"><i><div id="'+bezoeken.beoek_id+'img">';
                                                //content += '<img src="images/teamm-blanco.png" alt="">'
                                                content +='</div></i><span class="day_name">'+bezoeken.client+'</span><label></label><div class="clear"></div></a></li>';
                                          });

                                    }
                              }
                              content += '</ul>';
                        
                        }
                  });
//                  alert(sessionStorage.teamonline);
                  content += '<div id="groupdiv"  style="display:inline;margin:0px 0px 0px 30px"><img id="groupbutton" src="images/teamm-group64.png" style="margin:30px auto;" alt=""></div>';
                  content += '<div id="duurdiv"  style="display:inline;margin:0px 0px 0px 30px"><img id="duurbutton" src="images/teamm-start2wit64.png" style="margin:30px  auto;" alt=""></div>';
                  if (sessionStorage.teamonline=='N') {
                      content += '<li style="margin:20px; border-bottom:0px;"><a class="teamm"><span class="day_name"><br><br></span><label></label><div class="clear"></div></a></li>';
                  }
                  else{
                  content += '<div id="duurdiv2" style="display:none;"><li style="margin:20px; border-bottom:0px;"><a class="teamm"><span class="day_name" style="width:90%">Wijzigen duur: '+
                             '<input id="duurveld" class="dienstduur" name="duur" value="'+l_duur+'" type="time"/><br><br>'+
                             '<div id="verzuimdiv"  style="display:inline;"><img id="verzuimbutton" src="images/teamm-checkedwit64.png" style="display:block;margin:0 auto;" alt=""></div>'+    
                             '</span><label></label><div class="clear"></div></a></li></div>';
                  content += '<div id="groupdiv2" style="display:none;"><li style="margin:20px; border-bottom:0px;"><a class="teamm"><span class="day_name" style="width:90%">dienst toekennen: '+
                             '<div id="groupdiv3"  style="display:inline;"></div>'+                              
                             '<div id="groupdiv4"  style="display:inline;"><img id="groupopslagbutton" src="images/teamm-checkedwit64.png" style="display:block;margin:0 auto;" alt=""></div>'+    
                             '</span><label></label><div class="clear"></div></a></li></div>';                        
                             
                  }
                  content += '</ul>';
                   $("#teamm-bezoek").html(content);
            }
            
            function lees_taken(p_dienst) {
                  var content = '';
                  var contentww = '';
                  var contentrw = '';
                  var contentro = '';
                  var contentno='';
                  var l_duur  = '';
                  contentno += '<li style="margin:0px 0px 0px 20px; border-bottom:0px;"><a class="teamm"><span class="day_name"><br><br>'+
                             ''+
                             '</span><label></label><div class="clear"></div></a></li>';
                  contentww += '<li style="margin:0px 0px 0px 20px; border-bottom:0px;"><a class="teamm"><span class="day_name" style="width:90%; text-align:center;"><br><br>'+
                             '<div id="startdiv" style="display:inline;"><img id="startbutton" src="images/teamm-startwit64.png" style="display:inline;margin:0 auto;" alt=""></div>'+
                             '<div id="stopdiv" style="display:inline;"><img id="stopbutton" src="images/teamm-stopwit64.png" style="display:inline;margin:0 auto;" alt=""></div>'+
                             '<br><div id="groupdiv"  style="display:inline;"><img id="groupbutton" src="images/teamm-group64.png" style="display:inline;margin:0 auto;" alt=""></div>'+
                             '<div id="messdiv"  style="display:inline;"><img id="messbutton" src="images/teamm-aantekening.png" style="display:inline;margin:0 auto;" alt=""></div></span><label></label><div class="clear"></div></a></li>';
                  contentrw += '<li style="margin:0px 0px 0px 20px; border-bottom:0px;"><a class="teamm"><span class="day_name" style="width:90%; text-align:center;"><br><br>'+
                             '<div id="startdiv" style="display:inline;"><img id="" src="images/teamm-startgroen64.png" style="display:inline;margin:0 auto;" alt=""></div>'+
                             '<div id="stopdiv" style="display:inline;"><img id="stopbutton" src="images/teamm-stopwit64.png" style="display:inline;margin:0 auto;" alt=""></div></span><label></label><div class="clear"></div></a></li>';
                  contentro += '<li style="margin:0px 0px 0px 20px; border-bottom:0px;"><a class="teamm"><span class="day_name" style="width:90%; text-align:center;"><br><br>'+
                             '<div id="startdiv" style="display:inline;"><img id="" src="images/teamm-startgroen64.png" style="display:inline;margin:0 auto;" alt=""></div>'+
                             '<div id="stopdiv" style="display:inline;"><img id="stopbutton" src="images/teamm-stoprood64.png" style="display:inline;margin:0 auto;" alt=""></div></span><label></label><div class="clear"></div></a></li>';
      
           
                  
                  content += '<ul>';
            // lees hoogste in boom
                  $.each(p_dienst.items,function(i,dienstdata){
                        if (dienstdata.dienstid == sessionStorage.dienstid) {
                              if (JSON.stringify(dienstdata)!='null') {
                                    if (JSON.stringify(dienstdata).search('bezoeken') > -1) {
                                          sessionStorage.bezoeken = JSON.stringify(dienstdata);
                                          $.each(dienstdata.bezoeken,function(j,bezoeken){
                                                if (bezoeken.bezoek_id == sessionStorage.bezoekid) {
                                                      content += '<li><a  class="teamm">';
                                                      //content += '<i><div id="'+dienstdata.DIENSTID+'img">';
                                                      //content += '<img src="images/teamm-blanco.png" alt="">'
                                                      //content += '</div></i>';
                                                      content += '<span class="day_name">'+dienstdata.dag+' '+dienstdata.datum+'<br>'+dienstdata.klant+'<br>'+bezoeken.client+'<br></span><label></label><div class="clear"></div></a></li>';
                                                      content += '<ul style="margin: 0px 0px 0px 30px;">';       
                                                      if (JSON.stringify(bezoeken)!='null') {
                                                            if (JSON.stringify(bezoeken).search('taken') > -1) {
                                                                  sessionStorage.taken = JSON.stringify(bezoeken);
                                                                  $.each(bezoeken.taken,function(j,taken){
                                                                        //alert(taken.taak_code.length);
                                                                        if (taken.taak_code.length!=0) {
                                                                          content += '<li><a class="teamm"><i><div id="'+taken.taak_code+'img">';
                                                                          content +='</div></i><span class="day_name">'+taken.taak_naam+'</span><label></label><div class="clear"></div></a></li>';
                                                                        }
                                                                  });
                                                            }
                                                      }
                                                      content += '</ul>';
                                                      //
                                                      // Toon of verberg buttons
                                                      //
                                                      l_timer = '';
                                                      l_tmpobj= '';
                                                      if (localStorage.getItem('teammtimer')) {
                                                            l_timer=localStorage.getItem('teammtimer');
                                                      }
                                                      if (localStorage.getItem('teammsynctijden')) {
                                                            l_tmpobj = customFilter(JSON.parse(localStorage.getItem('teammsynctijden')),'bezoekid',bezoeken.bezoek_id);
                                                      }
                                                      if (bezoeken.eindtijd && bezoeken.starttijd) {
                                                          content += contentno;
                                                      }
                                                      else {
                                                         if (l_timer === 'ON'+bezoeken.bezoek_id) {  //currentbezoek actieve timer, dus ook object
                                                            if (l_tmpobj.starttijd.length>0 || bezoeken.starttijd) {
                                                                  if (l_tmpobj.eindtijd.length>0) {
                                                                        content += contentro;
                                                                    }
                                                                  else {
                                                                        content += contentrw;
                                                                    }
                                                             }
                                                             else {
                                                                  content += contentww;
                                                             }
                                                         }
                                                         else { //Timer ongelijk aan on<id>
                                                            if (l_timer.substring(0,2) === 'ON') { //startactief voor ander bezoek
                                                                  content += contentno;
                                                              }
                                                            else {  //timer off of leeg
                                                                  if (l_timer === 'OFF'+bezoeken.bezoek_id) { //Eindactief voor cur bezoek
                                                                        content += contentro;
                                                                  }
                                                                  else {
                                                                        if (l_timer.substring(0,3) === 'OFF') { //timer actief, ander bezoek, lokaal onbekend
                                                                           if (l_tmpobj) { //bezoek lokaal bekend, altijd start en eind toch?
                                                                              content += contentro;
                                                                           }
                                                                           else {
                                                                              if (bezoeken.starttijd) { //wel starttijd, geen eindtijd, geen timer
                                                                                     content += contentrw;
                                                                               }
                                                                               else { //Geen start en geen eind en geen timer
                                                                                     content += contentww;
                                                                               }                                                                              
                                                                           }
                                                                        }
                                                                        else {
                                                                              if (bezoeken.starttijd) { //wel starttijd, geen eindtijd, geen timer
                                                                                     content += contentrw;
                                                                               }
                                                                               else { //Geen start en geen eind en geen timer
                                                                                     content += contentww;
                                                                               }                                                                                                                                                            
                                                                              
                                                                        }

                                                                  }
                                                            }
                                                         }   
                                                      }
                                                      

                                                }  //bezoekdata
                                          });
                                    }
                              }
                        }

                  });
                  content += '</ul>';
                   $("#teamm-bezoek").html(content);
            }

            function findAndReplace_strt(object, p_key, p_value, p_replacekey1, p_replacevalue1, p_replacekey2, p_replacevalue2) {
            //
            // Zoek voor bepaalde key een waarde
            // vervang voor additionele key de waarde
            //
                  for(var x in object){
                        if(typeof object[x] == typeof {}){
                              o=findAndReplace(object[x], p_key,p_value, p_replacekey1, p_replacevalue1,p_replacekey2, p_replacevalue2);
                              if (o!=null) return o;
                        }
    
                        if(object[x] == p_value && object.hasOwnProperty(p_key) ){ 
                              object[p_replacekey1] = p_replacevalue1;
                              object[p_replacekey2] = p_replacevalue2;
                              return 'true';     // uncomment to stop after first replacement
                        }
                  }
                  return null;
            }
            
           function findAndReplace(object, p_key, p_value, p_replacekey1, p_replacevalue1) {
            //
            // Zoek voor bepaalde key een waarde
            // vervang voor additionele key de waarde
            //
                  for(var x in object){
                        if(typeof object[x] == typeof {}){
                              o=findAndReplace(object[x], p_key,p_value, p_replacekey1, p_replacevalue1);
                              if (o!=null) return o;
                        }
    
                        if(object[x] == p_value && object.hasOwnProperty(p_key) ){ 
                              object[p_replacekey1] = p_replacevalue1;
                              return 'true';     // uncomment to stop after first replacement
                        }
                  }
                  return null;
            }
            
            function customFilter(object,p_key,p_value){
                  //alert('q');
                if(object.hasOwnProperty(p_key) && object[p_key]==p_value)
                    return object;

                for(var i=0;i<Object.keys(object).length;i++){
                        if(typeof object[Object.keys(object)[i]]=="object"){
                              o=customFilter(object[Object.keys(object)[i]],p_key,p_value);
                              if (o!=null) return o;
                        }
                  }

                return null;
            }
         
            
            function opslag_bezoektijden(p_bezoek,p_type,p_tijd) {
                //
                // Lokaal opslaan start/stoptijden
                //    p_type  : starttijd of eindtijd
                //
                // Checks : Is starttijd al ingevuld voordat eindtijd ingevuld kan worden
                //          Als localstorage leeg is , ook geen eindtijd
                // Check of localstorage al gevuld is
                //
                // Get Current date + time
                localStorage.setItem('teammsync','Y');              // Gegevens worden lokaal opgeslagen, dienen dus gesynchroniseerd te worden
                if (!localStorage.getItem('teammsynctijden')) {
//                //  alert('leeg');
                  var l_inittijden = '{"bezoeken":[]}';
                  l_tijdenobj = JSON.parse(l_inittijden);
                  if (p_type =='start') {
                     l_tijdenobj.bezoeken.push({"bezoekid":p_bezoek,"starttijd":p_tijd,"eindtijd":'' });
                  }
                  else {
                     l_tijdenobj.bezoeken.push({"bezoekid":p_bezoek,"starttijd":'',"eindtijd":p_tijd });                        
                  }

                }
                else{
//                 // alert('Niet leeg');
                  var l_gevonden = '';
                  var l_tijdenobj = JSON.parse(localStorage.getItem('teammsynctijden'));
                  //l_bezoekobj = customFilter(l_tijdenobj,'bezoekid',p_bezoek);
                  if (p_type == 'start') {
                     l_gevonden = findAndReplace(l_tijdenobj, 'bezoekid',p_bezoek,'starttijd',p_tijd);
                     }
                  else {
                     l_gevonden = findAndReplace(l_tijdenobj, 'bezoekid',p_bezoek,'eindtijd', p_tijd);                        
                  }

                 if (!l_gevonden) {
                    //alert('bezoek niet aanwezig');
                    if (p_type =='start') {
                       l_tijdenobj.bezoeken.push({"bezoekid":p_bezoek,"starttijd":p_tijd,"eindtijd":'' });
                       }
                    else {
                       l_tijdenobj.bezoeken.push({"bezoekid":p_bezoek,"starttijd":'',"eindtijd":p_tijd });                        
                    }
                    //alert('bezoek new'+JSON.stringify(l_tijdenobj));
                  }
                }
            // Sla object weer op
            localStorage.setItem('teammsynctijden',JSON.stringify(l_tijdenobj));                  
            }

            function sync_bezoektijden() {
                  //
                  // Synchroniseer lokaal bestand met start/stoptijden
                  //      met database.
                  //      Als synchronisatie goed is verlopen, dan
                  //      wordt teammsync='N' en data opgeschoond.
                  //
                  var l_tijdenstring = localStorage.getItem('teammsynctijden');
                  l_tijdenobj = JSON.parse(l_tijdenstring);
                  //
                  // Alleen als sync=Y en string not empty
                  //
                  if (localStorage.getItem('teammsync')=='Y' && l_tijdenstring)  {
                        $.ajax({
                         url: "http://ts.teamm.nl:8080/"+localStorage.getItem('teamuri')+"/tijden",
          //               url:"http://ts.teamm.nl:8195/ords/ontw/rfm2/tijden",
                          type: "POST",
                          dataType:"text",
                          headers:{ 
                                   "tijdjson"  : l_tijdenstring,
                                   "app_token" : localStorage.getItem('teamtoken'),
			           "medewerker": localStorage.getItem('teamprofiel'),
                                   "klant"     : localStorage.getItem('teamklant')
                                },
                          success: function (data,status,jqXHR) {
                              //alert(data);
                              localStorage.setItem('teammsync','N');
                              localStorage.removeItem('teammsynctijden');
                              localStorage.setItem('teammtimer','OFF');
                              //alert(jqXHR.getResponseHeader('status'));
                              //alert('W'+data);
                               },
                          error: function(jqXHR,status,data) {
                              alert(data);
                              //Geen verdere actie, synchroniseren mislukt.
                              //alert(jqXHR.getResponseHeader('status'));
                              //alert('Service of server niet beschikbaar');
                              }
                        });
                  }
            }
            
            function sync_bezoektijden_index() {
                  //
                  // Synchroniseer lokaal bestand met start/stoptijden
                  //      met database.
                  //      Als synchronisatie goed is verlopen, dan
                  //      wordt teammsync='N' en data opgeschoond.
                  //
                  var l_tijdenstring = localStorage.getItem('teammsynctijden');
                  l_tijdenobj = JSON.parse(l_tijdenstring);
                  //
                  // Alleen als sync=Y en string not empty
                  //
                  if (localStorage.getItem('teammsync')=='Y' && l_tijdenstring)  {
                        $.ajax({
                         url: "http://ts.teamm.nl:8080/"+localStorage.getItem('teamuri')+"/tijden",
          //               url:"http://ts.teamm.nl:8195/ords/ontw/rfm2/tijden",
                          type: "POST",
                          dataType:"text",
                          headers:{ 
                                   "tijdjson"  : l_tijdenstring,
                                   "app_token" : localStorage.getItem('teamtoken'),
			           "medewerker": localStorage.getItem('teamprofiel'),
                                   "klant"     : localStorage.getItem('teamklant')
                                },
                          success: function (data,status,jqXHR) {
                              localStorage.setItem('teammsync','N');
                              localStorage.removeItem('teammsynctijden');
                              location.reload();
                              //alert(jqXHR.getResponseHeader('status'));
                              //alert('W'+data);
                               },
                          error: function(jqXHR,status,data) {
                              //alert(data);
                              //Geen verdere actie, synchroniseren mislukt.
                              //alert(jqXHR.getResponseHeader('status'));
                              //alert('Service of server niet beschikbaar');
                              }
                        });
                  }
            }

