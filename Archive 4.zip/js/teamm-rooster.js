/*
 Naam  : teamm-rooster.js
 Datum : 15-05-2016
 Auteur: Henk Kruize
 
 Ophalen menu + rooster en opslaan in lokale storage

*/
function lees_data(p_online) {
    var l_online = p_online;
		
    if (l_online=='1') {
	/* Er is internetverbinding */
	//var url='http://ts.teamm.nl:8195/apex/apex_rest.getReport?app=rfmapp&page=10&reportid=teammenu&parmvalues='+localStorage.getItem('teamprofiel')+'&output=json';
    	//$.getJSON(url,function(json) {
	//    localStorage.setItem('teammenu', JSON.stringify(json));
	    //lees_menu(json);
	//    });
//	var url='http://ts.teamm.nl:8195/ords/apex_rest.getReport?app='+localStorage.getItem('teammapp')+'&page=rooster&reportid=rooster_lang&parmvalues='+localStorage.getItem('teamprofiel')+','+localStorage.getItem('teamklant')+'&output=json';
        localStorage.removeItem('teammrooster');
	$.ajax({
			url: "http://ts.teamm.nl:8080/"+localStorage.getItem('teamuri')+"/rooster",
			type: "GET",
			dataType: "json",
			headers : {   
			   'medewerker' : localStorage.getItem('teamprofiel'),
			   'klant'      : localStorage.getItem('teamklant')
				   },
			success: function (data,status,jqXHR) {
			  if(data.items.length==0) {
			    //alert('leeg');
			    var l_1 = 1;
			  }
			  else {
			    //alert(JSON.stringify(data));
			    localStorage.setItem('teammrooster', JSON.stringify(data));
			    lees_rooster(data);
			  }
			},
                        error: function(jqXHR,status) {
                            alert('Service of server niet bereikbaar 3');
                            }
                    });	
	}
    else {
	/* Er is geen internetverbinding, haal lokale data op */
	//lees_menu(JSON.parse(localStorage.getItem('teammenu')));
	lees_rooster(JSON.parse(localStorage.getItem('teammrooster')));
	} 
  //  $('nav#menu').mmenu();
}