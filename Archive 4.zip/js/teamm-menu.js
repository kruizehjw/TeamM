function lees_data(p_online) {
    var l_online = p_online;
		
    if (l_online=='1') {
	var url='http://ts.teamm.nl:8080/ordsprd/apex_rest.getReport?app=110&page=10&reportid=teammenu&parmvalues='+localStorage.getItem('teamprofiel')+'&output=json';
    	$.getJSON(url,function(json) {
	    localStorage.setItem('teammenu', JSON.stringify(json));
	    lees_menu(json);
	    });
	//var url='http://apex.enciva.co.uk/pls/apex/apex_rest.getReport?app=356&page=350&reportid=vetbfluiten&output=json';
	var url='http://ts.teamm.nl:8080/ordsprd/apex_rest.getReport?app=110&page=10&reportid=rooster_lang&parmvalues='+localStorage.getItem('teamprofiel')+'&output=json';
    	$.getJSON(url,function(json) {
	    localStorage.setItem('teamroosterlang', JSON.stringify(json));
	    lees_roosterlang(json);
	    });
	
	}
    else {	     
	lees_menu(JSON.parse(localStorage.getItem('teammenu')));
	lees_roosterlang(JSON.parse(localStorage.getItem('teamroosterlang')));
	} //norefresh
    $('nav#menu').mmenu();
}