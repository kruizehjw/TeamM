function calendarDemoAdd() {
//    lees_roosterdel(JSON.parse(localStorage.getItem('teammroostersync'))); //Oud rooster
//    lees_roosterins(JSON.parse(localStorage.getItem('teammrooster')));     //Nieuw rooster
        
    
    var url3='http://ts.teamm.nl:8080/ordsprd/apex_rest.getReport?app=110&page=10&reportid=dienstenkortsync&parmvalues='+localStorage.getItem('teamprofiel')+'&output=json';
    $.getJSON(url3,function(json) {
        //Loop door de wedstrijden.
         //alert(JSON.stringify(json));
	$.each(json.row,function(i,tweet) {
                              // alert('delete');
              startDate = new Date(tweet.JAAR,tweet.MAAND,tweet.DAG,tweet.UUR,tweet.MIN,0,0,0);
              ddDate = new Date();
              endDate = new Date(tweet.JAAR,tweet.MAAND,tweet.DAG,tweet.UUR2,tweet.MIN2,0,0,0);
	      where = 'Op lokatie';
              title = tweet.ID;
	      notes = 'Opmerkingen : '+tweet.ID;
              window.plugins.calendar.deleteEvent(title,where,notes,ddDate,endDate);
             
        });
         //alert('Rijen verwijderd');
       $.each(json.row,function(i,tweet) {
               // alert('Insert');

              startDate = new Date(tweet.JAAR,tweet.MAAND,tweet.DAG,tweet.UUR,tweet.MIN,0,0,0);
              ddDate = new Date();
              endDate = new Date(tweet.JAAR,tweet.MAAND,tweet.DAG,tweet.UUR2,tweet.MIN2,0,0,0);
	      where = 'Op lokatie';
              title = tweet.ID;
	      notes = 'Opmerkingen : '+tweet.ID;
              //alert(notes);
              window.plugins.calendar.createEvent(title,where,notes,startDate,endDate);
              //alert('einde');
              
        });
       alert('Rooster is gesynchroniseerd');
        
    });  
}